import socket

# Créer un socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Envoie un paquet broadcast sur le réseau
sock.sendto(b'', ('255.255.255.255', 1))

# Récupère les adresses IP
while True:
    data, addr = sock.recvfrom(65536)
    print(addr[0])
