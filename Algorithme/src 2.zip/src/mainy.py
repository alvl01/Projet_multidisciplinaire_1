from adafruit_crickit import crickit
from color import TCS34725
import prog
from command import Command
sensor = TCS34725(board.I2C())
sensor.integration_time = 50
sensor.gain = 4
cmd = Command()
while True:
    if crickit.seesaw.analog_read(crickit.SIGNAL3) < 100:
        interpret_program(cmd, sensor)
